export { IngredientDetailsUI } from './ingredient-details';
